function toggleMenu() {
  var menu = document.querySelector('.menu');
  menu.style.display = (menu.style.display === 'flex') ? 'none' : 'flex';
}

let cartCount = 0;

function addToCart(productId) {
    cartCount++;
    document.getElementById('cart-icon').innerText = `🛒 ${cartCount}`;
    showPopup();
}